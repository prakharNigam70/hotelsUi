import { useHistory } from "react-router-dom";
import Authentication, { IAuthentication } from "./Authentication";


export default function Login(){
    const history = useHistory()
    const onSubmit = (login : IAuthentication) => {
        alert("Login Button invoked " + " " + login.email + " " + login.password)
    }
    return(
        <>
            <Authentication isUserNameVisible={false} title="Welcome to Login Page"
            onSubmit={onSubmit}
            tertiary={{
                label : "SignUp",
                onClick : ()=> history.push("/SignUp")
            }}
            />
        </>
    )
}