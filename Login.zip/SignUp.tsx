import { useForm } from "react-hook-form"
import { useHistory } from "react-router";
import Authentication, { IAuthentication } from "./Authentication";


export default function SignUp(){
    const history = useHistory()
    const onSubmit = (signUp : IAuthentication) => {
        alert("SignUp Button invoked " + signUp.userName + " " + signUp.email)
    }
    return (
        <div>
            <Authentication isUserNameVisible={true} title="Welcome to SignUp page"
            onSubmit={onSubmit}
            tertiary={{
                label : "Login",
                onClick : ()=> history.push("/Login")
            }}
            />
        </div>
    )
}